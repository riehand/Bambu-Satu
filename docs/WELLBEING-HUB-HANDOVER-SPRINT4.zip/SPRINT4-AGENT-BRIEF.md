# Agent Brief — WellBeing Hub Phase 4 Sprint 4

**Salin prompt ini ke Codex, Claude, atau coding agent yang dipakai pengembang penerus.**

---

You are the incoming Senior Full-Stack Engineer for the existing WellBeing Hub Capstone project. Continue development; do not rebuild it.

## Context and source of truth

- Repo: `https://github.com/riehand/Bambu-Satu`
- Base branch: `riehand_branch`; work on your **own feature branch** (for example `feat/phase4-sprint4-consultation`).
- Stack: Next.js App Router, React, TypeScript, Prisma 5.22, PostgreSQL, Supabase Auth/GoTrue, private Supabase Storage, Vitest, Playwright, Docker.
- Main roles: PARTICIPANT, PSYCHOLOGIST, SUPERADMIN.
- Data: sensitive mental-wellbeing assessment, report and consultation records. Preserve auth, active role checks, RLS, scoped consent and private Storage.
- Shared hosted database also belongs to Flutter/Chatbot team: **never modify hosted or `chatbot` objects**.

**Read these files before editing:**
1. `AGENTS.md` (if present)
2. `docs/PHASE4-HANDOVER-SPRINT4-ONWARD.md`
3. `docs/PHASE4-FEATURE-GAP-ANALYSIS.md`
4. `docs/PHASE4-SPRINT3-BOOKING-CONSENT.md`
5. `docs/PHASE3-STAGE3A-CONSULTATION-LIFECYCLE.md`
6. `docs/PHASE3-STAGE3B-HUMAN-CHAT.md`
7. `docs/PHASE3-STAGE3E1D-CROSS-PARTY-GATEWAYS.md`
8. `docs/PHASE3-STAGE3E1E-DAL-INTEGRATION.md`
9. Current source/routes/services/Prisma and local scripts.

If documents or code are missing, check branch/remote completeness with the owner. `git status` and source code are authoritative; past reports describe earlier environments.

## Product state

Sprint 1 (real local login → 35-answer assessment → results), Sprint 2 (real private PDF generation/download with attestation), and Sprint 3 (psychologist availability → real booking → both dashboards → PDF access → revoke/reconsent) were **PASS in isolated local environments**. Latest reported milestone: 579 unit/integration tests and 129 browser fixture tests passed, plus two real browser integration scenarios in Sprint 3. **Do not repeat these sprints unnecessarily.** Production is not approved.

Sprint 3's local database had booking/consent gateway but **had not installed lifecycle/chat gateway functions**. Inspect before installation. Existing components and services for lifecycle/chat were implemented in Phase 3A/3B and rehearsed with SQL gateways in Stage 3E.1D. Your job is to connect them to the actual website.

## Task now: Phase 4 Sprint 4 — Consultation Lifecycle & Human Chat

**Target user-visible journey:**

Confirmed appointment → both users check in → assigned psychologist starts consultation → participant and psychologist exchange messages → psychologist ends consultation → both users see COMPLETED and further send is rejected.

### Work sequence

1. Inspect Git status, previous reports, source code, installed gateway functions, current containers, bind addresses, DB identity, Auth and worker setup. Keep all existing work; do not reset/clean.
2. If local bootstrap is missing on your machine, create a safe reproducible setup with fresh synthetic credentials. Never use previous developer's `.tmp` secrets or hosted credentials. A browser test on a Vite fixture is not end-to-end acceptance.
3. Trace existing appointment and consultation frontend → API → service → DAL → PostgreSQL. Reuse `ConsultationDashboard`, chat panel, routes and Stage 3E.1D gateway contracts. Fix only the gaps.
4. Install local lifecycle/chat gateway prerequisites **only after** reviewing their SQL, role ownership, RLS, transaction requirements, catalog/current state, non-idempotence, and guard/marker. Clearly label local proposals TEST ONLY; no hosted work.
5. Use real participant and assigned psychologist synthetic accounts, two isolated browser sessions, and a real appointment created through existing UI. Validate both check-ins, correct start/end, chat persist/order, idempotent retry, and post-completion denial.
6. Preserve role/assignment checks, both check-ins, DB server time, transaction integrity, consent expiry, deferred chat trigger and Prisma postcommit confirmation. Admin/outsider must never read chat.
7. Apply existing development-only policy windows; **do not invent** rules for lateness, no-show, reschedule, retention, or reopening. If appointment time is not eligible (earlier fixture was 2 Dec 2026 09.00–11.00 WIB), use a deliberately isolated test clock only if existing architecture supports it safely, and label simulated time. Never edit DB timestamps using privileged shortcut or change the host clock.
8. Run targeted functional tests during coding. At the integration milestone, run unit, browser, TypeScript, lint, build and relevant migration checksum checks once. Do not create an extensive new security harness without concrete need.
9. Write `docs/PHASE4-SPRINT4-CONSULTATION-CHAT.md` with changed files, actual two-user browser steps/evidence, SQL persisted state, test outcomes, remaining gaps and institutional blockers. Claim PASS only for demonstrated local flow.

## Hard restrictions

- **No hosted Supabase access, migrations, deployment, or shared Flutter schema modifications.**
- No reset/clean, no deleting unknown Docker containers/volumes, no historical migration rewrites.
- No privileged fallback from `website_runtime`, no disabling RLS, no uncontrolled SECURITY DEFINER or access to chat via admin.
- No real participant or clinical data, no publishing worker/DB/Auth credentials.
- No activation of production check-in/start/chat; KKA approval remains pending.
- Do not commit/push/merge/deploy until the human owner asks. Work on a separate branch and submit a PR for review when authorized.

## After Sprint 4 (do not start automatically)

- **Sprint 5:** Super Admin operational overview, academic periods, psychologist roster and appointment monitoring using restricted read projections and operational aggregates. Do not expose individual report/score/chat.
- **Sprint 6:** cross-role integration, final functional regression, security review, accessibility, KKA UAT, and controlled rollout planning after approvals.
- Keep separate backlog: appointment-specific consultation mode; standalone-consent inbox for psychologist; signer custody, key rotation and hosted acceptance.

## Start now

Summarize the smallest blockers you found and **begin implementing Sprint 4**. Show progress through working UI and persisted records rather than reporting only test counts. Stop after Sprint 4 acceptance and handover report.
