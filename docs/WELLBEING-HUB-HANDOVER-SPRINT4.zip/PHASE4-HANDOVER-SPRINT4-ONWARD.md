# WellBeing Hub — Serah Terima Pengembangan (Sprint 4 dan Seterusnya)

**Tanggal penyusunan:** 25 November 2026  
**Proyek:** WellBeing Hub / Bambu-Satu (Capstone kelompok)  
**Repository:** `https://github.com/riehand/Bambu-Satu`  
**Branch sumber pekerjaan:** `riehand_branch`  
**Status rilis:** **BELUM SIAP PRODUKSI** — keberhasilan yang disebut di bawah hanya berlaku pada lingkungan lokal sintetis.

> Dokumen ini adalah panduan bagi pengembang dan coding agent penerus. **Periksa source code, status Git, dan log aktual** sebelum bertindak; laporan sprint adalah bukti historis, bukan jaminan environment saat ini masih aktif. Jangan mencampur proyek Capstone kelompok ini dengan TA pribadi anggota tim.

## 1. Tujuan produk dan pemilik fitur

WellBeing Hub menghubungkan peserta, psikolog, dan SUPERADMIN untuk asesmen kesejahteraan mental, pengunduhan laporan pribadi, pemesanan konsultasi, dan pemantauan operasional. Ekosistem lain, khususnya aplikasi Flutter/Chatbot, memakai sebagian layanan database bersama; **schema `chatbot` milik tim lain** dan tidak boleh diubah.

- **Participant:** register/login, consent pemrosesan, DASS-21 + WEMWBS, simpan/lanjutkan, hasil/riwayat, PDF privat, pilih psikolog dan slot, booking, consent laporan, check-in, chat konsultasi (hanya pengujian lokal selama belum ada persetujuan).
- **Psychologist:** login, profil, ketersediaan, daftar/detail appointment, melihat laporan dengan consent sah, check-in, memulai/mengakhiri konsultasi, chat (hanya lokal selama belum ada persetujuan).
- **SUPERADMIN:** ringkasan operasional, periode akademik, daftar psikolog dan janji, monitoring teragregasi. **Tidak boleh** membaca jawaban/skor individual, PDF, atau isi chat secara otomatis.

## 2. Tech stack dan arsitektur saat handover

- Next.js App Router 16.4.6, React 19, TypeScript, Prisma 5.22.
- PostgreSQL 17 digunakan dalam pengujian lokal. Supabase Auth/GoTrue dan private Supabase Storage.
- Browser tests: Playwright; unit/integrasi: Vitest; Docker untuk layanan lokal.
- **Batas identitas:** Supabase Auth `auth.users.id` = `public.users.id`; halaman/API memeriksa user/role aktif; DAL membawa signed transaction context ke Prisma `website_runtime`.
- **Database gateway:** SQL fungsi terbatas untuk scoring, booking, consent, lifecycle, chat; RLS/grants menjaga isolasi. Mode DAL nonprivileged yang diuji masih dibatasi ke konfigurasi lokal/test; bukan otomasi produksi.
- **PDF:** local worker terpisah `wb_pdf_worker`, bucket private `assessment-reports`, upload create-only, read-back, digest/attestation, finalisasi baru menjadi `GENERATED` setelah verifikasi.
- **Skema data bersama:** website utamanya `public`, Flutter mempunyai schema/ledger sendiri; jangan menyentuh objek Flutter atau migrasi Auth bersama. Delapan checksum website migrations telah diverifikasi dalam sprint terakhir.

**Penting:** SQL di `docs/sql/stage3e1*` dan `docs/sql/phase4-sprint*` adalah proposal/adaptasi **lokal/test**. Sebagian tidak idempotent dan **bukan instruksi migrasi hosted**. Jangan jalankan otomatis di proyek Supabase bersama.

## 3. Hasil yang SUDAH terbukti pada website lokal

| Milestone | Hasil nyata | Status |
|---|---|---|
| Sprint 1 — asesmen | Login GoTrue lokal → dashboard participant → jawab 35 soal → simpan/reload → submit → skor official & report PENDING di PostgreSQL; akses user lain ditolak | **PASS lokal** |
| Sprint 2 — PDF | Participant membuat PDF dari PENDING → Storage private → GENERATED dengan attestation → browser download dan digest/bytes sama; Storage outage → 503/PENDING → retry berhasil | **PASS lokal** |
| Sprint 3 — booking & consent | Psikolog buat availability → peserta booking dengan **PDF nyata** dan consent eksplisit → appointment muncul di kedua akun → download psikolog → revoke → ditolak → reconsent → akses pulih; double booking 409 | **PASS inti lokal** |

Baseline regresi terkini dari laporan Sprint 3: **579** tes unit/integrasi, **129** tes browser harness, **70** tes terarah; TypeScript/lint/build lulus (dua warning `<img>` lama); migrasi 8/8 checksum cocok. Laporan Sprint 3 juga merekam **dua skenario browser website nyata**. Angka ini **bukan** hasil uji di laptop teman dan tidak membuktikan produksi siap.

Dokumen penting, bacalah berurutan:

1. `AGENTS.md` (jika tersedia) dan `docs/PHASE4-FEATURE-GAP-ANALYSIS.md`
2. `docs/PHASE4-SPRINT1-ASSESSMENT-FLOW.md`
3. `docs/PHASE4-SPRINT2-PDF-FLOW.md`
4. `docs/PHASE4-SPRINT3-BOOKING-CONSENT.md`
5. `docs/PHASE3-STAGE3E1E-DAL-INTEGRATION.md`
6. `docs/PHASE3-STAGE3E1D-CROSS-PARTY-GATEWAYS.md`
7. `docs/PHASE3-STAGE3A-CONSULTATION-LIFECYCLE.md`
8. `docs/PHASE3-STAGE3B-HUMAN-CHAT.md`
9. `prisma/schema.prisma`, `package.json`, `src/lib/dal/`, serta route/service yang terkait.

Jika file yang tercantum tidak ada setelah clone, **berhenti dan cek apakah seluruh perubahan lokal sudah di-commit dan di-push oleh pemilik awal**. Jangan mengasumsikan branch remote sudah mencakup pekerjaan yang belum dikirim.

## 4. Sisa pekerjaan berdasarkan prioritas

### Sprint 4 — Consultation Lifecycle & Human Chat (prioritas langsung)

**Sasaran:** lewat dua browser berakun sintetis, kedua pihak membuka appointment yang sama → participant check-in → psychologist check-in → psychologist start → dua arah chat persist → psychologist end → keduanya melihat COMPLETED → pengiriman baru ditolak.

Yang sudah ada:
- Komponen `ConsultationDashboard`, `ChatPanel`, API actions/messages, service lifecycle/chat, policy development, dan gateway SQL Stage 3E.1D.
- Booking Sprint 3 membuat appointment `CONFIRMED` dan consultation `SCHEDULED`.

**Titik putus saat handover:** laporan Sprint 3 menyatakan **fungsi `transition_consultation`, `send_message`, `read_messages` belum dipasang pada database lokal website tersebut**. Audit katalog aktual sebelum menambah SQL. Jangan memasang gateway berulang secara membabi buta.

Prioritas implementasi:
1. Periksa service → DAL → gateway → database, beserta API dan UI yang sudah ada.
2. Siapkan *secara aman dan khusus lokal* gateway lifecycle/chat dari proposal Stage 3E.1D sesuai kebutuhan; tidak membuat ulang service.
3. Pastikan check-in/start/end yang sesuai *existing development policy*, status appointment dan consultation sinkron, expiry consent mengikuti aturan tersimpan.
4. Pastikan chat hanya dua pihak assigned ketika IN_PROGRESS; retry idempotent, pesan persist setelah commit, tidak bisa send setelah end, admin dan outsider ditolak.
5. Gunakan dua sesi browser nyata pada Next.js lokal, bukan Vite visual fixture sebagai bukti utama.
6. Uji jam/jendela sesi secara sah. **Contoh appointment Sprint 3 adalah 2 Desember 2026, 09.00–11.00 WIB, yang belum tentu berada dalam jendela eligible saat pengujian.** Jangan ubah timestamp DB dengan role privileged sebagai shortcut atau mengubah jam OS. Bila perlu gunakan test clock yang *benar-benar terisolasi* dan laporkan sebagai simulated-time acceptance.
7. Pertahankan gate lifecycle/chat produksi **DISABLED**, sampai keputusan KKA disetujui.

**Output:** `docs/PHASE4-SPRINT4-CONSULTATION-CHAT.md`, bukti browser dua peran, status database persisted, tes terarah, daftar perubahan dan risiko sisa. Definisi PASS harus berdasarkan perjalanan lokal nyata, bukan sekadar green tests.

### Sprint 5 — Super Admin Dashboard

Selesaikan halaman admin operasional yang tersedia: aggregate overview, daftar/detail periode, monitoring psikolog/availability dan appointment. Gunakan read projection/aggregate terbatas, bukan SELECT data klinis yang luas. Tampilkan kondisi *unavailable* secara eksplisit bila backend belum mendukung (jangan mengganti angka menjadi nol palsu). Jangan mengaktifkan kontrol periode/role yang belum mendapat mandat KKA. Dokumentasikan browser acceptance peran admin dan larangan akses score/PDF/chat individu.

### Sprint 6 — Integrasi akhir dan UAT

Lakukan lintas peran untuk alur dari asesmen hingga konsultasi/monitoring; regresi lengkap, review keamanan minimum (RLS/consent/Storage), cek accessibility dan UX, bukti backup/restore/staging yang disetujui, serta UAT dengan stakeholder KKA. **Tidak menjalankan hosted rollout** tanpa keputusan dan izin eksplisit.

### Backlog di luar sprint inti

- Pilihan mode konsultasi **per appointment** belum ada; metode yang tampil saat ini berasal dari profil psikolog. Perlu keputusan apakah produk memerlukan multi-mode dan snapshot pada saat booking.
- Inbox psikolog untuk **consent mandiri tanpa appointment** masih belum terhubung ke UI (grant/revoke peserta sudah ada).
- Keputusan operasional KKA: durasi sesi, toleransi terlambat, NO_SHOW, cancel/reschedule, reopening, chat retention dan akses pascasesi, kewenangan admin, aktivasi periode dan kuota.
- Worker/signer custody, rotasi key, hosted/staging acceptance, approval klinis/licensing kuesioner, dan kebijakan privasi masih syarat sebelum produksi.
- Report lama GENERATED **tanpa attestation** tidak boleh otomatis dianggap tepercaya oleh jalur download baru.

## 5. Menyiapkan environment teman (tanpa berbagi secrets)

**Yang ADA di Git:** source, tests, migrations historis, SQL proposal lokal, dokumentasi bila pemilik sudah push.

**Yang TIDAK ADA di Git:** `.env.local`, `.tmp/phase4-*`, konfigurasi runtime/worker yang diabaikan, synthetic DB dan Storage volumes, local Auth users, PDF/credential test artifacts, proses/container yang sedang hidup di laptop pengembang awal.

Prinsip bootstrap:

1. Clone/pull branch yang telah di-push dan periksa commit hash, `git status`, `package.json`.
2. Install dependencies sesuai lockfile (`npm ci` apabila toolchain kompatibel) dan konfigurasi Node yang sesuai.
3. Siapkan **stack lokal baru** (PostgreSQL, GoTrue, Storage, worker) dengan **kredensial sintetis baru**, tidak meminjam kredensial/volume teman.
4. Pastikan semua port yang dipublikasikan hanya `127.0.0.1`, semua URL lokal, role `website_runtime` non-superuser/non-BYPASSRLS, tidak ada hosted linkage.
5. Terapkan migrations dan SQL lokal **hanya setelah memverifikasi guard/marker serta dependensi urutannya**; sebagian proposal `phase4-sprint2/3` tidak idempotent, jadi jangan auto-run semua dokumen SQL.
6. Provision synthetic accounts dari Auth lokal, role masing-masing, active period dan question sets yang valid. Jangan menggunakan data mahasiswa nyata.
7. Jalankan Next.js dan browser acceptance. Pertama cek apakah Sprint 1–3 masih berfungsi pada clone milik teman sebelum memperbaiki Sprint 4.
8. Jangan menyalin file credential lain ke chat/commit/issue. Dokumentasikan **nama variabel** yang dibutuhkan tanpa nilainya.

Jika bootstrap belum reproducible dari source yang sudah di-push, buat langkah setup lokal yang aman dan terdokumentasi, tanpa memindahkan `.tmp` mentah atau file secret. Jangan memalsukan milestone PASS saat belum bisa start.

## 6. Aturan keamanan/kolaborasi

- Jangan sentuh Supabase **hosted/shared**, `chatbot` schema atau shared Auth triggers; semua perubahan database untuk sprint ini lokal sintetis.
- Jangan `prisma db push`, `prisma migrate reset`, `supabase link`, atau menerapkan SQL proposal ke hosted tanpa persetujuan.
- Jangan gunakan postgres, table owner, deployer, `service_role`, atau BYPASSRLS sebagai fallback untuk Next.js runtime.
- Jangan menonaktifkan RLS, melonggarkan consent, memalsukan PDF GENERATED, atau membocorkan URL Storage publik.
- Jangan mengaktifkan produksi check-in/start/chat sebelum kebijakan KKA disetujui.
- Jangan commit/push/deploy tanpa instruksi pemilik branch; teman sebaiknya bekerja lewat **branch fitur dan pull request**.
- Jangan memasukkan `.env*`, `.tmp`, file PDF hasil pengujian, logs berisi token, screenshot sensitif, atau file `tatus` yang sebelumnya pernah muncul sebagai untracked.
- Perubahan SQL lokal diberi label **TEST ONLY / HOSTED NOT EXECUTED**.

## 7. Definition of done dan bukti

**Satu sprint = satu perjalanan yang benar-benar bisa dijalankan melalui website lokal.** Unit test, mocked browser fixture, dan tes database adalah bukti pendukung, bukan pengganti UI.

Untuk Sprint 4 kumpulkan:
- Respons auth dan navigasi 2 sesi browser.
- Screenshot tiap state check-in/IN_PROGRESS/COMPLETED tanpa data rahasia.
- Bukti request API berhasil/gagal yang relevan (tanpa token).
- Query PostgreSQL read-only untuk appointment/session/messages/consent audit.
- Penolakan user lain dan post-end chat.
- Test fungsional terarah, TypeScript/lint, full regression **sekali setelah milestone selesai**.
- Daftar source/SQL yang berubah, environment boundary, status `PASS | PARTIAL | BLOCKED` yang jujur.

## 8. Alur kerja Git untuk kolaborasi

### Bagi pemilik repo sebelum serah terima

1. Pastikan seluruh pekerjaan Sprint 1–3 dan Phase 3 yang diperlukan **sudah menjadi commit lokal**.
2. Periksa `git status --short`, staging, nama/isi file sensitif, dan diff; **jangan** `git add .`, `git reset --hard`, atau `git clean`.
3. Push `riehand_branch` dan pastikan commit remote sama dengan lokal.
4. Beri teman akses baca/kolaborasi ke repo melalui pengaturan GitHub yang sesuai; **jangan kirim token lewat chat**.
5. Bagikan dokumen ini dan agent brief di repo, bukan credential lokal.

### Bagi teman

```powershell
git clone https://github.com/riehand/Bambu-Satu.git
cd Bambu-Satu
git fetch origin
git switch -c feat/phase4-sprint4-consultation origin/riehand_branch
git status
```

Jika sudah mempunyai clone, lakukan `git fetch origin` dan buat branch baru dari `origin/riehand_branch` ketika worktree bersih. Setelah Sprint 4, ajukan PR dari `feat/phase4-sprint4-consultation` menuju `riehand_branch` untuk direview, **bukan langsung menggabungkan ke branch utama**.

## 9. Penanda serah terima

- [ ] Branch remote `riehand_branch` berisi seluruh source/dokumen yang dibutuhkan Sprint 1–3.
- [ ] Tidak ada credential, `.env.local`, `.tmp`, PDF sintetis, atau data sensitif di commit.
- [ ] Teman berhasil clone dan melihat dokumen handover serta semua route/services terkait.
- [ ] Environment sintetis milik teman dipisah dari hosted dan laptop pemilik lama.
- [ ] Agent sudah membaca report Sprint 3, Stage 3E.1D, dan daftar blocker Sprint 4.
- [ ] Scope Sprint 4 dan aturan PR telah disepakati.

